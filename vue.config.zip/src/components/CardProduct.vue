<template>
  <div class="input-group mb-3">
  <input type="text" class="form-control" placeholder="Recipient's username" aria-label="Recipient's username" aria-describedby="button-addon2" v-model="busqueda">
  <button class="btn btn-outline-secondary" type="button" id="button-addon2" @click="searchMovie()">Button</button>
</div>
  <div class="container mb-5">
    <div class="row d-flex justify-content-center">
      <div v-for="(item, index) in result" :key="index" class="card" style="width: 22rem;">
        <img v-bind:src="item.image" class="card-img-top" v-bind:alt="item.title">
        <div class="card-body">
          <h5 class="card-title">{{ item.title }}</h5>
          <p class="card-text">{{ item.director }}</p>
          <a href="#" class="btn btn-primary">Más detalles</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script>

export default {
  name: 'CardProduct',
 data(){
    return {
      result: [],
      busqueda: 'hola',
      }
  },
  mounted(){
      fetch("https://ghibliapi.herokuapp.com/films/")
      .then(res => res.json())
      .then(data => this.result = data)
  },
  methods: {
    searchMovie(){
      console.log(this.busqueda)
    }
  }
}
</script>

<style>

</style>